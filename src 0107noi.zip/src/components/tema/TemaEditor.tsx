'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Check, ZoomIn, EyeOff } from 'lucide-react'

interface Tema {
  id: string
  nome: string
  config: any
  ativo: boolean
}

interface TemaEditorProps {
  estabelecimentoId: string
  temaAtualId: string | null
  readOnly?: boolean
  onTemaChange?: (temaId: string) => void
}

// Dados mockados para preview (apenas PT)
const ITENS_PREVIEW = [
  {
    id: '1',
    nome: 'Salmão Grelhado',
    descricao: 'Salmão grelhado com legumes salteados e molho de ervas.',
    preco: 45.0,
    codigo: '042',
    foto_url: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&auto=format&fit=crop',
    alergenos: ['Glúten', 'Peixe'],
    promocao_ativa: true,
    preco_promocional: 38.0,
  },
  {
    id: '2',
    nome: 'Mousse de Queijo Feta',
    descricao: 'Mousse leve de queijo feta com mel e nozes.',
    preco: 34.0,
    codigo: '021',
    foto_url: 'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=400&auto=format&fit=crop',
    alergenos: ['Leite', 'Nozes'],
    promocao_ativa: false,
    preco_promocional: null,
  },
  {
    id: '3',
    nome: 'Risoto de Cogumelos',
    descricao: 'Risoto cremoso com cogumelos frescos e parmesão.',
    preco: 52.0,
    codigo: '019',
    foto_url: 'https://images.unsplash.com/photo-1556760543-2b3b3a1f8f2c?w=400&auto=format&fit=crop',
    alergenos: ['Lactose', 'Glúten'],
    promocao_ativa: false,
    preco_promocional: null,
  },
]

export default function TemaEditor({
  estabelecimentoId,
  temaAtualId,
  readOnly = false,
  onTemaChange,
}: TemaEditorProps) {
  const supabase = createClient()
  const [temas, setTemas] = useState<Tema[]>([])
  const [loading, setLoading] = useState(true)
  const [selecionado, setSelecionado] = useState<string | null>(temaAtualId)
  const [salvando, setSalvando] = useState(false)
  const [mensagem, setMensagem] = useState<{ tipo: 'success' | 'error'; texto: string } | null>(null)

  const [layoutFoto, setLayoutFoto] = useState<'direita' | 'esquerda' | 'topo' | 'ocultar'>('direita')
  const [mostrarCodigo, setMostrarCodigo] = useState(true)
  const [mostrarAlergenos, setMostrarAlergenos] = useState(true)
  const [modalAberto, setModalAberto] = useState(false)
  const [modalItem, setModalItem] = useState<any>(null)
  const [tituloCardapio, setTituloCardapio] = useState('Meu Cardápio')

  useEffect(() => {
    const carregarTemas = async () => {
      const { data, error } = await supabase
        .from('temas')
        .select('*')
        .eq('ativo', true)
        .order('nome', { ascending: true })

      if (error) {
        console.error('Erro ao carregar temas:', error)
        setMensagem({ tipo: 'error', texto: 'Erro ao carregar temas.' })
      } else {
        setTemas(data || [])
      }
      setLoading(false)
    }
    carregarTemas()
  }, [supabase])

  const selecionarTema = async (temaId: string) => {
    if (readOnly || salvando) return
    setSalvando(true)
    setMensagem(null)

    const { error } = await supabase
      .from('estabelecimentos')
      .update({ tema_atual_id: temaId })
      .eq('id', estabelecimentoId)

    if (error) {
      setMensagem({ tipo: 'error', texto: 'Erro ao salvar tema: ' + error.message })
    } else {
      setSelecionado(temaId)
      setMensagem({ tipo: 'success', texto: '✅ Tema atualizado com sucesso!' })
      if (onTemaChange) onTemaChange(temaId)
    }
    setSalvando(false)
  }

  const abrirModalFoto = (item: any) => {
    setModalItem(item)
    setModalAberto(true)
  }

  const temaAtual = temas.find(t => t.id === selecionado) || temas[0]
  const config = temaAtual?.config || {}

  const corPrimaria = config.cor_primaria || '#f97316'
  const corSecundaria = config.cor_secundaria || '#ffffff'
  const corFundo = config.cor_fundo || '#f9fafb'
  const corTexto = config.cor_texto || '#1f2937'
  const corCard = config.cor_card || '#ffffff'
  const corBadge = config.cor_badge || corPrimaria
  const corBorda = config.cor_borda || `${corPrimaria}30`

  const formatarPreco = (valor: number) =>
    valor?.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

  const mostrarFoto = layoutFoto !== 'ocultar'

  if (loading) return <div className="text-center py-8 text-gray-500">Carregando temas...</div>

  if (temas.length === 0) {
    return <div className="text-center py-8 text-gray-500">Nenhum tema disponível. Crie temas no banco de dados.</div>
  }

  return (
    <div className="space-y-6">
      {mensagem && (
        <div
          className={`p-3 rounded-lg text-sm ${
            mensagem.tipo === 'success'
              ? 'bg-green-50 text-green-700 border border-green-200'
              : 'bg-red-50 text-red-700 border border-red-200'
          }`}
        >
          {mensagem.texto}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Painel esquerdo – controles */}
        <div className="space-y-4 order-2 xl:order-1">
          {/* Seleção de tema */}
          <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">🎨 Escolha o tema</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {temas.map((tema) => {
                const cfg = tema.config || {}
                const isSelected = selecionado === tema.id
                return (
                  <button
                    key={tema.id}
                    onClick={() => selecionarTema(tema.id)}
                    disabled={readOnly || salvando}
                    className={`
                      relative p-3 rounded-xl border-2 text-left transition-all
                      ${isSelected ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'}
                      ${readOnly || salvando ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}
                    `}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-full border border-gray-200 flex-shrink-0"
                        style={{ backgroundColor: cfg.cor_primaria || '#f97316' }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm text-gray-800 truncate">{tema.nome}</p>
                        <p className="text-xs text-gray-400 truncate">
                          {cfg.cor_primaria && cfg.cor_secundaria ? `${cfg.cor_primaria} • ${cfg.cor_secundaria}` : ''}
                        </p>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-orange-500 flex-shrink-0" />}
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Layout e visibilidade */}
          <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">🖼️ Opções de exibição</h3>

            <div className="mb-4">
              <label className="block text-xs font-medium text-gray-600 mb-2">Posição da foto</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { value: 'direita', label: 'À direita' },
                  { value: 'esquerda', label: 'À esquerda' },
                  { value: 'topo', label: 'Acima' },
                  { value: 'ocultar', label: 'Sem foto', icon: <EyeOff className="w-3 h-3" /> },
                ].map((opcao) => (
                  <button
                    key={opcao.value}
                    onClick={() => setLayoutFoto(opcao.value as any)}
                    className={`flex items-center justify-center gap-1 py-2 text-xs font-medium rounded-lg border transition ${
                      layoutFoto === opcao.value
                        ? 'border-orange-500 bg-orange-50 text-orange-700'
                        : 'border-gray-200 text-gray-600 hover:border-gray-300'
                    }`}
                  >
                    {opcao.icon && opcao.icon}
                    {opcao.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-medium text-gray-600 mb-1">Exibir no cardápio</label>
              <div className="flex flex-wrap gap-4">
                <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={mostrarCodigo}
                    onChange={(e) => setMostrarCodigo(e.target.checked)}
                    className="w-4 h-4 accent-orange-500"
                  />
                  Código do item
                </label>
                <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={mostrarAlergenos}
                    onChange={(e) => setMostrarAlergenos(e.target.checked)}
                    className="w-4 h-4 accent-orange-500"
                  />
                  Alérgenos
                </label>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-100">
              <label className="block text-xs font-medium text-gray-600 mb-1">Título do cardápio</label>
              <input
                type="text"
                value={tituloCardapio}
                onChange={(e) => setTituloCardapio(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
              />
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm flex items-center justify-between">
            <span className="text-sm text-gray-600">Tema atual:</span>
            <span className="text-sm font-semibold text-gray-800">
              {temas.find(t => t.id === selecionado)?.nome || 'Nenhum'}
            </span>
          </div>
        </div>

        {/* Painel direito – preview responsivo */}
        <div className="order-1 xl:order-2">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
              <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">📱 Pré-visualização</span>
              <span className="text-xs text-gray-400">(clique na lupa para ampliar)</span>
            </div>
            <div className="p-4">
              <div
                className="mx-auto max-w-sm rounded-2xl overflow-hidden shadow-lg border"
                style={{
                  backgroundColor: corFundo,
                  color: corTexto,
                  borderColor: corBorda,
                }}
              >
                {/* Cabeçalho */}
                <div
                  className="p-4 border-b"
                  style={{
                    backgroundColor: corSecundaria,
                    borderColor: corBorda,
                  }}
                >
                  <h3 className="text-lg font-bold text-center" style={{ color: corPrimaria }}>
                    🍽️ {tituloCardapio}
                  </h3>
                  <p className="text-xs text-center opacity-60 mt-1" style={{ color: corTexto }}>
                    Tema: {temaAtual?.nome}
                  </p>
                </div>

                {/* Lista de itens */}
                <div className="p-3 space-y-4">
                  {ITENS_PREVIEW.map((item, index) => {
                    const posicaoFoto = layoutFoto
                    const isTopo = posicaoFoto === 'topo'
                    const isOcultar = posicaoFoto === 'ocultar'
                    const isEsquerda = posicaoFoto === 'esquerda'
                    const isDireita = posicaoFoto === 'direita'

                    // Aplica flex-direction baseado na posição
                    let flexDirection = 'flex-row'
                    if (isTopo) flexDirection = 'flex-col'
                    else if (isEsquerda) flexDirection = 'flex-row-reverse'
                    else flexDirection = 'flex-row' // direita

                    return (
                      <div
                        key={item.id}
                        className="rounded-lg p-3 shadow-sm"
                        style={{
                          backgroundColor: corCard,
                          border: `1px solid ${corBorda}`,
                        }}
                      >
                        <div className={`flex ${flexDirection} gap-3 items-start`}>
                          {/* Foto – se não estiver oculta */}
                          {!isOcultar && (
                            <div className={`flex-shrink-0 ${isTopo ? 'w-full' : 'w-20 md:w-24'}`}>
                              <div
                                className={`${isTopo ? 'w-full h-32' : 'w-20 h-20 md:w-24 md:h-24'} rounded-lg overflow-hidden bg-gray-100 border border-gray-200 relative`}
                              >
                                <img
                                  src={item.foto_url || 'https://via.placeholder.com/400x300?text=Sem+Imagem'}
                                  alt={item.nome}
                                  className="w-full h-full object-cover"
                                />
                                <button
                                  onClick={() => abrirModalFoto(item)}
                                  className="absolute bottom-1 right-1 w-6 h-6 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/80 transition"
                                >
                                  <ZoomIn className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          )}

                          {/* Conteúdo do item */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-baseline justify-between gap-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                {mostrarCodigo && item.codigo && (
                                  <span
                                    className="text-xs font-mono px-1.5 py-0.5 rounded"
                                    style={{ backgroundColor: `${corPrimaria}15`, color: corPrimaria }}
                                  >
                                    #{item.codigo}
                                  </span>
                                )}
                                <span className="font-medium text-sm" style={{ color: corTexto }}>
                                  {item.nome}
                                </span>
                                {item.promocao_ativa && (
                                  <span
                                    className="text-xs px-1.5 py-0.5 rounded-full text-white font-medium"
                                    style={{ backgroundColor: corBadge }}
                                  >
                                    🔥 Promoção
                                  </span>
                                )}
                              </div>
                              <div className="text-right flex-shrink-0">
                                {item.promocao_ativa && item.preco_promocional ? (
                                  <>
                                    <span className="text-xs text-gray-400 line-through">
                                      R$ {formatarPreco(item.preco)}
                                    </span>
                                    <span className="text-sm font-bold ml-1" style={{ color: corPrimaria }}>
                                      R$ {formatarPreco(item.preco_promocional)}
                                    </span>
                                  </>
                                ) : (
                                  <span className="text-sm font-bold" style={{ color: corPrimaria }}>
                                    R$ {formatarPreco(item.preco)}
                                  </span>
                                )}
                              </div>
                            </div>
                            <p className="text-xs opacity-70 mt-1 line-clamp-2" style={{ color: corTexto }}>
                              {item.descricao}
                            </p>
                            {mostrarAlergenos && item.alergenos && item.alergenos.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-2">
                                {item.alergenos.map((alergeno) => (
                                  <span
                                    key={alergeno}
                                    className="text-xs px-2 py-0.5 rounded-full border border-amber-200"
                                    style={{ backgroundColor: '#fef3c7', color: '#92400e' }}
                                  >
                                    ⚠️ {alergeno}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal de ampliação */}
      {modalAberto && modalItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
          onClick={() => setModalAberto(false)}
        >
          <div
            className="bg-white rounded-xl max-w-md w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <img
                src={modalItem.foto_url || 'https://via.placeholder.com/800x600?text=Sem+Imagem'}
                alt={modalItem.nome}
                className="w-full h-auto max-h-[60vh] object-contain bg-gray-100"
              />
              <button
                onClick={() => setModalAberto(false)}
                className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/50 text-white hover:bg-black/70 flex items-center justify-center transition"
              >
                ✕
              </button>
            </div>
            <div className="p-4">
              <h4 className="font-semibold text-gray-800">{modalItem.nome}</h4>
              <p className="text-sm text-gray-500">{modalItem.descricao}</p>
              <p className="text-sm font-bold text-orange-600 mt-1">R$ {formatarPreco(modalItem.preco)}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}