import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import { getOptimizedCloudinaryUrl } from '@/lib/cloudinary'
import { Metadata } from 'next'

// ============================================================
// METADADOS DINÂMICOS (SEO)
// ============================================================

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const { slug } = await params
  const supabase = await createClient()

  const { data: estabelecimento, error } = await supabase
    .from('estabelecimentos')
    .select('nome, nome_fantasia, descricao, bairro, slug, foto_capa')
    .eq('slug', slug)
    .eq('status', 'active')
    .eq('ativo', true)
    .single()

  if (error || !estabelecimento) {
    return {
      title: 'Cardápio - Menu Salvador',
      description: 'Confira o cardápio digital deste estabelecimento.',
    }
  }

  const nomeExibicao = estabelecimento.nome_fantasia || estabelecimento.nome
  const descricao = estabelecimento.descricao || `Cardápio digital do ${nomeExibicao} em ${estabelecimento.bairro}.`
  const imageUrl = estabelecimento.foto_capa || '/default-og-image.jpg'

  return {
    title: `${nomeExibicao} - Cardápio Digital`,
    description: descricao,
    openGraph: {
      title: `${nomeExibicao} - Cardápio Digital`,
      description: descricao,
      url: `/cardapio/${slug}`,
      siteName: 'Menu Salvador',
      images: [
        {
          url: imageUrl,
          width: 1200,
          height: 630,
          alt: `Cardápio do ${nomeExibicao}`,
        },
      ],
      locale: 'pt_BR',
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: `${nomeExibicao} - Cardápio Digital`,
      description: descricao,
      images: [imageUrl],
    },
    alternates: {
      canonical: `/cardapio/${slug}`,
    },
    robots: {
      index: true,
      follow: true,
    },
  }
}

// ============================================================
// PÁGINA PRINCIPAL
// ============================================================

export default async function CardapioPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const supabase = await createClient()
  const { slug } = await params

  // 1. Buscar estabelecimento
  const { data: estabelecimento, error: estError } = await supabase
    .from('estabelecimentos')
    .select('*')
    .eq('slug', slug)
    .eq('status', 'active')
    .eq('ativo', true)
    .single()

  if (estError || !estabelecimento) notFound()

  // 2. Buscar tema e ler configurações diretamente
  let temaConfig: any = {}
  if (estabelecimento.tema_atual_id) {
    const { data: tema } = await supabase
      .from('temas')
      .select('config')
      .eq('id', estabelecimento.tema_atual_id)
      .single()
    if (tema) temaConfig = tema.config || {}
  }

  // ===== CORES DO TEMA (mapeamento direto) =====
  const corPrimaria = temaConfig.cor_primaria || '#f97316'
  const corSecundaria = temaConfig.cor_secundaria || '#ffffff'
  const corFundo = temaConfig.cor_fundo || '#f9fafb'
  const corTexto = temaConfig.cor_texto || '#1f2937'
  const corBadge = temaConfig.cor_badge || corPrimaria
  const corBorda = temaConfig.cor_borda || `${corPrimaria}40`

  // ===== OPÇÕES DO TEMA (fallbacks) =====
  const fotoPosicao = temaConfig.foto_posicao || 'left' // left | right | top | none
  const mostrarCodigo = temaConfig.mostrar_codigo !== false // default true
  const mostrarAlergenos = temaConfig.mostrar_alergenos !== false // default true
  const tituloCardapio = temaConfig.titulo || estabelecimento.nome_fantasia || estabelecimento.nome

  // 3. Buscar menu ativo e itens (com alérgenos)
  const { data: menu } = await supabase
    .from('menus')
    .select('id')
    .eq('estabelecimento_id', estabelecimento.id)
    .eq('ativo', true)
    .single()

  let categorias: any[] = []
  let itensPorCategoria: Record<string, any[]> = {}

  if (menu) {
    const { data: cats } = await supabase
      .from('categorias')
      .select('*')
      .eq('menu_id', menu.id)
      .order('ordem', { ascending: true })

    if (cats && cats.length > 0) {
      categorias = cats
      const ids = cats.map((c) => c.id)
      const { data: itens } = await supabase
        .from('itens_cardapio')
        .select(`
          *,
          item_allergens (
            allergen:allergen_id (id, nome, icone)
          )
        `)
        .in('categoria_id', ids)
        .eq('disponivel', true)
        .order('ordem', { ascending: true })

      if (itens) {
        cats.forEach((cat) => {
          itensPorCategoria[cat.id] = itens.filter(
            (item) => item.categoria_id === cat.id
          )
        })
      }
    }
  }

  const logoUrl = estabelecimento.logo_url
  const totalItens = Object.values(itensPorCategoria).reduce(
    (acc, items) => acc + items.length,
    0
  )

  const formatarPreco = (valor: number) =>
    valor?.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

  const getAlergenos = (item: any) => {
    if (!item.item_allergens || item.item_allergens.length === 0) return []
    return item.item_allergens.map((rel: any) => rel.allergen).filter(Boolean)
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: corFundo, color: corTexto }}>
      <div className="mx-auto max-w-4xl px-4 pt-8">
        {/* Cabeçalho com tema */}
        <div
          className="rounded-2xl p-6 shadow-lg"
          style={{
            backgroundColor: corSecundaria,
            border: `1px solid ${corBorda}`,
          }}
        >
          <div className="flex items-center gap-4">
            {logoUrl && (
              <div
                className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-full border-2"
                style={{ borderColor: corPrimaria }}
              >
                <Image
                  src={logoUrl}
                  alt={tituloCardapio}
                  fill
                  className="object-cover"
                  sizes="64px"
                  unoptimized={true}
                  priority
                />
              </div>
            )}
            <div>
              <h1
                className="text-2xl font-bold"
                style={{ color: corPrimaria }}
              >
                {tituloCardapio}
              </h1>
              <p className="text-sm" style={{ color: corTexto }}>
                {estabelecimento.bairro} • {estabelecimento.tipo_cozinha || 'Cozinha variada'}
              </p>
              <p className="mt-1 text-xs" style={{ color: corTexto }}>
                {totalItens} itens • {categorias.length} categorias
              </p>
            </div>
          </div>
          <Link
            href={`/${estabelecimento.cidade}/${estabelecimento.bairro}/${estabelecimento.tipo_estabelecimento}/${estabelecimento.slug}`}
            className="mt-3 inline-block text-sm hover:underline"
            style={{ color: corPrimaria }}
          >
            ← Voltar ao perfil
          </Link>
        </div>

        {/* Navegação rápida por categorias */}
        {categorias.length > 1 && (
          <div
            className="sticky top-0 z-30 mt-6 border-b backdrop-blur-sm"
            style={{ backgroundColor: `${corFundo}e6`, borderColor: corBorda }}
          >
            <div className="flex max-w-4xl gap-2 overflow-x-auto px-4 py-3">
              {categorias.map((cat) => {
                const itens = itensPorCategoria[cat.id] || []
                if (itens.length === 0) return null
                return (
                  <a
                    key={cat.id}
                    href={`#categoria-${cat.id}`}
                    className="flex-shrink-0 whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition"
                    style={{
                      backgroundColor: `${corPrimaria}15`,
                      color: corPrimaria,
                    }}
                  >
                    {cat.nome}
                  </a>
                )
              })}
            </div>
          </div>
        )}

        {/* Cardápio */}
        <div className="mt-6 pb-10">
          {categorias.length === 0 ? (
            <div
              className="rounded-2xl p-12 text-center shadow"
              style={{ backgroundColor: corSecundaria, color: corTexto }}
            >
              <p className="text-lg font-medium">Nenhum item disponível no cardápio</p>
              <p className="text-sm">Volte em breve para novidades!</p>
            </div>
          ) : (
            <div className="space-y-8">
              {categorias.map((cat) => {
                const itens = itensPorCategoria[cat.id] || []
                if (itens.length === 0) return null

                return (
                  <div
                    key={cat.id}
                    id={`categoria-${cat.id}`}
                    className="scroll-mt-20 overflow-hidden rounded-2xl shadow-lg"
                    style={{ backgroundColor: corSecundaria }}
                  >
                    {/* Cabeçalho da categoria */}
                    <div
                      className="border-b px-6 py-3"
                      style={{
                        backgroundColor: `${corPrimaria}15`,
                        borderColor: corBorda,
                      }}
                    >
                      <h2 className="text-lg font-semibold" style={{ color: corPrimaria }}>
                        {cat.nome}
                        <span className="ml-2 text-sm font-normal" style={{ color: corTexto }}>
                          ({itens.length})
                        </span>
                      </h2>
                    </div>

                    {/* Itens */}
                    <div className="divide-y divide-gray-100">
                      {itens.map((item) => {
                        const fotoUrl = getOptimizedCloudinaryUrl(item.foto_url, 300, 300, 'fill')
                        const alergenos = getAlergenos(item)

                        // Layout da foto conforme tema
                        const fotoClasse = fotoPosicao === 'right'
                          ? 'flex-row-reverse'
                          : fotoPosicao === 'top'
                          ? 'flex-col'
                          : 'flex-row'
                        const tamanhoFoto = fotoPosicao === 'top' ? 'h-48 w-full' : 'h-24 w-24'
                        const fotoSizes = fotoPosicao === 'top' ? '400px' : '96px'

                        return (
                          <div key={item.id} className="group p-4 transition hover:bg-gray-50/50">
                            <div className={`flex ${fotoClasse} gap-4 items-start`}>
                              {/* Foto */}
                              {fotoPosicao !== 'none' && fotoUrl && (
                                <div
                                  className={`${tamanhoFoto} relative flex-shrink-0 overflow-hidden rounded-xl bg-gray-100`}
                                >
                                  <Image
                                    src={fotoUrl}
                                    alt={item.nome}
                                    fill
                                    className="object-cover transition duration-300 group-hover:scale-105"
                                    sizes={fotoSizes}
                                    unoptimized={true}
                                    loading="lazy"
                                  />
                                </div>
                              )}

                              <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between gap-2">
                                  <div>
                                    <div className="flex flex-wrap items-center gap-2">
                                      {mostrarCodigo && item.codigo && (
                                        <span
                                          className="rounded-full px-2 py-0.5 font-mono text-xs"
                                          style={{
                                            backgroundColor: `${corPrimaria}20`,
                                            color: corPrimaria,
                                          }}
                                        >
                                          {item.codigo}
                                        </span>
                                      )}
                                      <h3 className="font-medium" style={{ color: corTexto }}>
                                        {item.nome}
                                      </h3>
                                      {item.promocao_ativa && (
                                        <span
                                          className="rounded-full px-2 py-0.5 text-xs font-medium"
                                          style={{
                                            backgroundColor: `${corPrimaria}20`,
                                            color: corPrimaria,
                                          }}
                                        >
                                          🔥 Promoção
                                        </span>
                                      )}
                                      {item.delivery_disponivel && (
                                        <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs text-blue-700">
                                          🛵 Delivery
                                        </span>
                                      )}
                                    </div>
                                    {item.descricao && (
                                      <p className="mt-1 text-sm" style={{ color: corTexto }}>
                                        {item.descricao}
                                      </p>
                                    )}
                                    {mostrarAlergenos && alergenos.length > 0 && (
                                      <div className="mt-2 flex flex-wrap gap-1">
                                        {alergenos.map((a: any) => (
                                          <span
                                            key={a.id}
                                            className="flex items-center gap-0.5 rounded-full bg-amber-50 px-2 py-0.5 text-xs text-amber-700"
                                            title={`Alérgeno: ${a.nome}`}
                                          >
                                            {a.icone && <span>{a.icone}</span>}
                                            {a.nome}
                                          </span>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                  <div className="whitespace-nowrap text-right">
                                    {item.promocao_ativa && item.preco_promocional ? (
                                      <div>
                                        <span className="text-xs text-gray-400 line-through">
                                          R$ {formatarPreco(item.preco)}
                                        </span>
                                        <span
                                          className="ml-2 text-lg font-bold"
                                          style={{ color: corPrimaria }}
                                        >
                                          R$ {formatarPreco(item.preco_promocional)}
                                        </span>
                                      </div>
                                    ) : (
                                      <span
                                        className="text-lg font-bold"
                                        style={{ color: corPrimaria }}
                                      >
                                        R$ {formatarPreco(item.preco)}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}